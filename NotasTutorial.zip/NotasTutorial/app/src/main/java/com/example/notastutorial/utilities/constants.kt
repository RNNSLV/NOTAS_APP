package com.example.notastutorial.utilities


val DATABASE_NAME = "note_database"