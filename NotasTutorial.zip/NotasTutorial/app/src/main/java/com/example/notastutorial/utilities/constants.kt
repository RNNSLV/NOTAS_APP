package com.example.notastutorial.utilities


val DATABASE_NAME: Nothing = TODO()